# Rilo Maxer — Website Portfolio Starter

A responsive, multi-page portfolio website for **Rilo Maxer®** by **Aryan B. Shewale**. Built with HTML, CSS, and lightweight vanilla JavaScript—no frameworks or build step required.

## Pages included

- `index.html` — agency homepage, animated headline, selected concept work, process, and CTA
- `work.html` — concept gallery with working category filters
- `services.html` — service descriptions and expandable FAQs
- `about.html` — founder/studio introduction
- `contact.html` — structured website project brief form
- `demo-healthcare.html` — fictional healthcare/clinic website concept
- `demo-cafe.html` — fictional café/restaurant website concept
- `demo-creator.html` — fictional creative portfolio concept
- `assets/css/style.css` — all styling and responsive layouts
- `assets/js/main.js` — mobile menu, headline animation, scroll reveals, category filters, and dynamic footer year

## Open it in an editor

1. Extract the ZIP file.
2. Open the `rilo-maxer-portfolio` folder in VS Code (or your preferred editor).
3. Run `index.html` with a local web server/Live Server extension for the best local preview. The pages also work as normal static HTML files, though form services may require the site to be served over HTTP/HTTPS.

## IMPORTANT: connect the enquiry form to your email

The contact form is wired to FormSubmit, which can deliver form submissions to an email address without you building a backend. The email is a placeholder until you change it:

1. Open `contact.html`.
2. Find `https://formsubmit.co/YOUR_EMAIL@example.com` in the form's `action` attribute.
3. Replace `YOUR_EMAIL@example.com` with the email inbox where you want to receive project enquiries.
4. Search the project files for `YOUR_EMAIL@example.com` and replace it in the footer `mailto:` links too.
5. Deploy the site to a public HTTPS URL, open the contact form on that deployed site, and send one test enquiry. FormSubmit sends an activation/confirmation email to your target inbox the first time; open it and confirm. Check spam/junk if needed.
6. Submit another test enquiry after confirmation. Verify that all fields arrive as expected before publishing the site widely.

FormSubmit documentation: https://formsubmit.co/documentation

**Don't share the placeholder version publicly and expect emails to arrive.** The form won't reach you until your actual inbox is added and the activation step is completed. FormSubmit is a third-party service; its availability and anti-spam checks are outside this project's control.

## Images and fonts

Google Fonts and several Unsplash images are loaded from external URLs. The website therefore uses internet access for those resources. Replace them with your own licensed/approved assets as appropriate. A remote stock photo is not evidence of a real client project.

## Before you use it as your public portfolio

- Replace placeholder email references with your professional inbox.
- Add verified contact/social links you actually control; none have been invented here.
- Review your services, pricing, availability, and delivery claims so they reflect what you can deliver.
- The Wellnest Health, The Daily Pour, and Studio Aarav pages are expressly labelled as **fictional concept projects**, not completed client projects or real businesses. Keep those labels unless you replace the pages with genuine, authorized case studies.
- Test every page on a phone and desktop after deployment.

## Notes

- No framework, package manager, or build command is required.
- The form requests a consent checkbox and includes a hidden honeypot field. FormSubmit may still show its own confirmation or anti-spam flow.
- This is a frontend starter, not a custom backend or CRM. It doesn't store submissions in your own database.
