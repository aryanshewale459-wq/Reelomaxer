(() => {
  'use strict';
  const $ = (selector, root = document) => root.querySelector(selector);
  const $$ = (selector, root = document) => [...root.querySelectorAll(selector)];

  // Keep the footer year current without manual edits.
  $$('[data-year]').forEach((node) => { node.textContent = new Date().getFullYear(); });

  // Mobile menu: accessible state and automatic close after choosing a page.
  const toggle = $('.nav-toggle');
  const nav = $('.nav-links');
  if (toggle && nav) {
    const closeNav = () => {
      toggle.setAttribute('aria-expanded', 'false');
      toggle.setAttribute('aria-label', 'Open navigation');
      nav.classList.remove('open');
      document.body.classList.remove('menu-open');
    };
    toggle.addEventListener('click', () => {
      const open = toggle.getAttribute('aria-expanded') !== 'true';
      toggle.setAttribute('aria-expanded', String(open));
      toggle.setAttribute('aria-label', open ? 'Close navigation' : 'Open navigation');
      nav.classList.toggle('open', open);
      document.body.classList.toggle('menu-open', open);
    });
    $$('a', nav).forEach((link) => link.addEventListener('click', closeNav));
    window.addEventListener('resize', () => { if (window.innerWidth > 680) closeNav(); });
  }

  // Subtle word rotation in the home hero; keep the static first word if JS is blocked.
  const rotating = $('[data-rotate]');
  if (rotating) {
    const words = (rotating.dataset.rotate || '').split(',').map((word) => word.trim()).filter(Boolean);
    if (words.length > 1 && !window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
      let index = 0;
      window.setInterval(() => {
        index = (index + 1) % words.length;
        rotating.classList.add('word-changing');
        window.setTimeout(() => {
          rotating.textContent = words[index];
          rotating.classList.remove('word-changing');
        }, 180);
      }, 2600);
    }
  }

  // Reveal project cards as they enter the viewport; gracefully show everything if unavailable.
  const revealItems = $$('[data-reveal]');
  if ('IntersectionObserver' in window && revealItems.length && !window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
    document.documentElement.classList.add('js-ready');
    const observer = new IntersectionObserver((entries, instance) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          entry.target.classList.add('is-visible');
          instance.unobserve(entry.target);
        }
      });
    }, { threshold: 0.12 });
    revealItems.forEach((item, index) => {
      item.style.transitionDelay = `${Math.min(index % 3, 2) * 80}ms`;
      observer.observe(item);
    });
  }

  // Portfolio category filters.
  const filterButtons = $$('[data-filter]');
  const filterCards = $$('[data-category]');
  if (filterButtons.length && filterCards.length) {
    filterButtons.forEach((button) => button.addEventListener('click', () => {
      const filter = button.dataset.filter;
      filterButtons.forEach((item) => item.classList.toggle('active', item === button));
      filterCards.forEach((card) => { card.hidden = filter !== 'all' && card.dataset.category !== filter; });
    }));
  }
})();
